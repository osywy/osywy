These textures along with many others are available from:

http://nobiax.deviantart.com/

Many thanks to Nobiax for making these freely available!
